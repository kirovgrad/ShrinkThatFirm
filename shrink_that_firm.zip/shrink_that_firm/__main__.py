"""Enable ``python -m shrink_that_firm``."""

import sys

from .cli import main

if __name__ == "__main__":
    sys.exit(main())
