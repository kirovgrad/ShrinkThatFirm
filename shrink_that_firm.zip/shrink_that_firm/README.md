# ShrinkThatFirm — rewritten

A from-scratch, more maintainable rewrite of the original firmware-shrinking
analyzer. It finds the same four classes of waste, plus the IDA-based unused
function analysis, without the original's sharp edges.

## What changed

| Concern | Original | Rewrite |
| --- | --- | --- |
| Intermediate CSV | files written to CWD then re-parsed by hand | in-memory typed records (`models.CollectedFile`) |
| Shared state | global `utils._STRINGCOLLECT` mutated from `main.py` | explicit `StringIndex` object passed to finders |
| `DT_NEEDED` parsing | external `readelf` + text parsing | pure-Python `elf.parse_needed_libraries` (no external binary, 32/64-bit, both endians) |
| Shell usage | `grep ... | head -1` built via string interpolation | no shell; regex over the in-memory string index |
| Exception handling | `except: pass` everywhere | narrow, logged handlers |
| Path handling | `os.path` + `full_path.index(root)` | `pathlib` + `relative_to` |
| Windows-only habits | `file.split("\\")[-1]` | `Path.name` |
| Reports | hard-coded CWD filenames | configurable `--output-dir` (default `./reports`) |
| Progress | ad-hoc `printProgressBar` | thread-safe `ProgressBar` (`stderr` logs keep it clean) |
| Entry point | `python main.py <fsdir> <threads>` | `python -m shrink_that_firm <root> [options]` |

## Layout

```
shrink_that_firm/
├── cli.py            # argument parsing + pipeline orchestration
├── config.py         # immutable per-run Config
├── models.py         # CollectedFile / FunctionGroup / UnusedEntry ...
├── elf.py            # pure-Python ELF parsing (is_elf, DT_NEEDED)
├── fs.py             # filesystem walking, md5, lib/binary indexing
├── strings.py        # parallel string collection + indexed word search
├── dup_files.py      # duplicate file detection
├── dup_funcs.py      # duplicate function detection (r2pipe)
├── unused_libs.py    # unused shared library detection
├── unused_bins.py    # unused binary detection
├── report.py         # text report generation + summary
├── progress.py       # logging setup + progress bar
└── ida/
    ├── idalib_finder.py  # headless IDA driver (IDA Pro 9+ / idalib)
    └── idb_script.py     # IDA script run inside each database
```

## Usage

```bash
python -m shrink_that_firm <fsdir> [-t THREADS] [-o REPORTS_DIR] [--no-dup-funcs]
```

* `fsdir` — path to the extracted firmware filesystem (required).
* `-t/--threads` — worker threads (default 8).
* `-o/--output-dir` — where reports are written (default `./reports`).
* `--no-dup-funcs` — skip the radare2 duplicate-function analysis.
* `--min-func-size`, `--min-string-len` — analysis tuning knobs.

Reports written: `duplicated_files_report.txt`, `duplicated_functions_report.txt`,
`unused_library_report.txt`, `unused_binary_report.txt` and `summary.txt`.

## Optional dependencies

* `r2pipe` — required only for the duplicate-function analysis step
  (`pip install r2pipe`); the other four steps run without it.
* IDA Pro 9+ — required for the unused-function analysis:

```bash
python -m shrink_that_firm.ida.idalib_finder <fsdir> [options]
```

Inside IDA Pro you can also run `ida/idb_script.py` directly as an IDAPython
script. Configure its paths via the `STF_STRINGS_JSON`, `STF_RESULT_JSON`,
`STF_MIN_FUNC_SIZE` and `STF_INCLUDE_SMALL` environment variables.

## Notes on accuracy (inherited from the original design)

The "unused" analyses are heuristics, not proofs:

* a library may be `dlopen`ed at runtime; the string search tries to catch
  that, but names in compressed/obfuscated data will be missed,
* C functions invoked through function pointers that IDA cannot resolve may be
  flagged unused (PRIVATE functions, inlined small functions), which is why the
  small-function filter defaults to keeping functions under 140 bytes
  (`STF_MIN_FUNC_SIZE`).

## Tests

Run from anywhere in the repository:

```bash
python3 run_tests.py
```

(or from the repository root: `python3 -m unittest discover -s shrink_that_firm/tests -t shrink_that_firm`)

The tests synthesize minimal valid ELF64 images to exercise the parser and run
the whole pipeline over a fake firmware filesystem, so they need no real
binaries, `readelf`, radare2 or IDA.
