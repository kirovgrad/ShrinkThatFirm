"""Filesystem scanning helpers.

Replaces ``fs_collector.py`` (which wrote an unescaped CSV and then re-parsed it)
and the ``find_binary_files`` helper in the old ``utils.py``.

The scan is now a single walk that produces typed ``CollectedFile`` records in
memory, so no intermediate file is needed and paths containing commas can no
longer corrupt the results.
"""

from __future__ import annotations

import hashlib
import os
from collections import defaultdict
from pathlib import Path
from typing import AbstractSet, Iterator

from .elf import is_elf
from .models import CollectedFile


def walk_files(root: Path, exclude: AbstractSet[Path] = frozenset()) -> Iterator[Path]:
    """Yield every file under ``root``, pruning excluded directories.

    ``exclude`` contains paths that must not be scanned (e.g. the report
    output directory when it is created inside the firmware tree).
    """
    excluded = {p.resolve() for p in exclude}
    for dirpath, dirnames, filenames in os.walk(root):
        base = Path(dirpath)
        dirnames[:] = [
            name
            for name in dirnames
            if (base / name).resolve() not in excluded
        ]
        for name in filenames:
            yield base / name


def md5(path: str | Path, chunk_size: int = 65536) -> str:
    """Streaming MD5 digest of a file."""
    digest = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_files(root: Path, exclude: AbstractSet[Path] = frozenset()) -> list[CollectedFile]:
    """Recursively collect regular files under ``root``.

    Symlinks are skipped (their targets are collected separately when the
    target directory is walked). Returns records sorted by path for
    deterministic output.
    """
    files: list[CollectedFile] = []
    for path in walk_files(root, exclude):
        try:
            st = path.lstat()
        except OSError:
            continue
        if st.st_mode & 0o170000 != 0o100000:  # not a regular file
            continue
        files.append(
            CollectedFile(
                path=path,
                size=st.st_size,
                mtime=st.st_mtime,
                md5=md5(path),
            )
        )
    return sorted(files, key=lambda f: f.path.as_posix())


def _is_so_name(name: str) -> bool:
    return name.endswith(".so") or ".so." in name


def index_elf_objects(
    root: Path, libs_only: bool = False, exclude: AbstractSet[Path] = frozenset()
) -> dict[Path, list[Path]]:
    """Map each ELF real path to the list of symlink aliases pointing at it.

    * ``libs_only=True``  -> only shared libraries (``.so`` / ``.so.N``).
    * ``libs_only=False`` -> only non-library ELF files (executables/objects).

    This replaces the old ``find_binary_files`` whose boolean logic was
    inverted and hard to follow. Keys are absolute real paths.
    """
    objects: dict[Path, list[Path]] = defaultdict(list)

    for path in walk_files(root, exclude):
        is_lib = _is_so_name(path.name)
        if is_lib != libs_only:
            continue

        if path.is_symlink():
            try:
                target = path.resolve()
            except (OSError, RuntimeError):
                continue
            if target.exists() and is_elf(target):
                objects[target].append(path)
        elif is_elf(path):
            objects.setdefault(path, [])

    return dict(sorted(objects.items(), key=lambda kv: kv[0].as_posix()))
