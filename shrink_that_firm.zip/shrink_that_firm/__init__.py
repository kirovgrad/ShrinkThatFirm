"""ShrinkThatFirm - analyze a firmware filesystem to find shrinkable waste.

The package is a from-scratch, more maintainable rewrite of the original
flat-script implementation. It keeps the same analysis pipeline while adding:

* a proper package layout with a CLI entry point (``python -m shrink_that_firm``),
* typed data models instead of ad-hoc dicts and CSV files,
* a pure-Python ELF parser (no external ``readelf``/``r2pipe`` needed for the
  "NEEDED section" analysis),
* dependency injection instead of global mutable state (the old
  ``utils._STRINGCOLLECT`` hack),
* configurable report output directory,
* an indexed in-memory string store with early-exit searches.
"""

__version__ = "2.0.0"
