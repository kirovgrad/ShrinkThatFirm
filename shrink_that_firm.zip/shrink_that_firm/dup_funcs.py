"""Duplicate function detection across binaries using radare2.

Semantics match the original ``dup_funcs_finder.py``:

* only functions living in the ``.text`` section are considered,
* functions smaller than ``min_size`` bytes are skipped (thunks/trivia),
* functions are grouped by the SHA-256 of their raw opcode bytes,
* groups sharing an opcode hash are further sub-grouped by size buckets so
  that only near-identical sizes are treated as duplicates.

The original leaked radare2 sessions on exceptions and used ``from utils import *``;
this version closes sessions deterministically and lazy-imports ``r2pipe`` so the
rest of the package keeps working on hosts without it.
"""

from __future__ import annotations

import concurrent.futures
import hashlib
from collections import defaultdict
from pathlib import Path
from typing import Sequence

from .config import Config
from .elf import is_elf
from .models import FunctionGroup, FunctionInfo
from .progress import ProgressBar, get_logger

logger = get_logger()


def _analyze_one(path: Path, min_size: int) -> list[FunctionInfo]:
    """Analyze a single ELF with radare2 and return its functions."""
    try:
        import r2pipe
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "r2pipe is required for duplicate-function analysis. "
            "Install it with: pip install r2pipe"
        ) from exc

    try:
        r2 = r2pipe.open(str(path))
        r2.cmd("aaa")

        text = next(
            (sec for sec in r2.cmdj("iSj") if sec.get("name") == ".text"),
            None,
        )
        if not text:
            return []

        text_start = text["vaddr"]
        text_end = text_start + text["vsize"]

        functions: list[FunctionInfo] = []
        for func in r2.cmdj("aflj"):
            addr, size, name = func["offset"], func["size"], func["name"]
            if size < min_size or not (text_start <= addr < text_end):
                continue
            opcodes = r2.cmd(f"p8 {size} @ {addr}")
            if not opcodes:
                continue
            functions.append(
                FunctionInfo(
                    binary=path,
                    name=name or f"unnamed_{addr:x}",
                    size=size,
                    opcode_hash=hashlib.sha256(opcodes.encode()).hexdigest(),
                    offset=addr,
                )
            )
        return functions
    except Exception as exc:  # noqa: BLE001 - analysis errors must not abort the scan
        logger.debug("Failed to analyze %s: %s", path, exc)
        return []
    finally:
        try:
            r2.quit()
        except (NameError, Exception):  # noqa: BLE001 - r2 may not have opened
            pass


def _r2pipe_available() -> bool:
    try:
        import r2pipe  # noqa: F401
        return True
    except ImportError:
        return False


def find_duplicate_functions(config: Config, binaries: Sequence[Path]) -> list[FunctionGroup]:
    """Analyze each ELF binary and return groups of duplicated functions."""
    elf_binaries = [p for p in binaries if is_elf(p)]
    if not elf_binaries:
        logger.info("No ELF binaries to analyze for duplicate functions.")
        return []

    if not _r2pipe_available():
        logger.warning(
            "Skipping duplicate-function analysis: r2pipe is not installed. "
            "Install it with: pip install r2pipe"
        )
        return []

    logger.info("Analyzing %d ELF binaries with radare2...", len(elf_binaries))

    functions: list[FunctionInfo] = []
    bar = ProgressBar(len(elf_binaries))
    with concurrent.futures.ThreadPoolExecutor(max_workers=config.threads) as pool:
        futures = [pool.submit(_analyze_one, p, config.dup_func_min_size) for p in elf_binaries]
        for done in concurrent.futures.as_completed(futures):
            functions.extend(done.result())
            bar.update()

    by_hash: dict[str, list[FunctionInfo]] = defaultdict(list)
    for func in functions:
        by_hash[func.opcode_hash].append(func)

    groups: list[FunctionGroup] = []
    for opcode_hash, same_opcodes in by_hash.items():
        if len(same_opcodes) < 2:
            continue
        # Bucket by ~10% size so non-identical functions don't collide.
        by_size: dict[int, list[FunctionInfo]] = defaultdict(list)
        for func in same_opcodes:
            by_size[round(func.size * 0.1)].append(func)
        for similar in by_size.values():
            if len(similar) > 1:
                groups.append(
                    FunctionGroup(
                        functions=tuple(similar),
                        opcode_hash=opcode_hash,
                        size=similar[0].size,
                    )
                )

    return sorted(groups, key=lambda g: g.wasted, reverse=True)
