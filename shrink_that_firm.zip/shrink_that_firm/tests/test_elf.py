"""Tests for the pure-Python ELF parser."""

from __future__ import annotations

import struct
import tempfile
import unittest
from pathlib import Path

from shrink_that_firm.elf import is_elf, is_shared_object, parse_needed_libraries

from .elf_builder import ET_DYN, ET_EXEC, build_elf64


class ElfParserTest(unittest.TestCase):
    def _write(self, data: bytes, suffix: str = ".bin") -> Path:
        tmp = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
        tmp.write(data)
        tmp.close()
        return Path(tmp.name)

    def test_is_elf(self) -> None:
        good = self._write(b"\x7fELF" + bytes(20))
        self.assertTrue(is_elf(good))
        bad = self._write(b"MZ" + bytes(20))
        self.assertFalse(is_elf(bad))
        missing = Path("/nonexistent/does-not-exist")
        self.assertFalse(is_elf(missing))

    def test_needed_libs_exec(self) -> None:
        path = self._write(
            build_elf64(needed=["libfoo.so", "libbar.so.1"], e_type=ET_EXEC)
        )
        self.assertEqual(parse_needed_libraries(path), {"libfoo.so", "libbar.so.1"})
        self.assertFalse(is_shared_object(path))

    def test_needed_libs_shared_object(self) -> None:
        path = self._write(
            build_elf64(needed=["libc.so.6"], soname="libfoo.so", e_type=ET_DYN, base=0)
        )
        self.assertEqual(parse_needed_libraries(path), {"libc.so.6"})
        self.assertTrue(is_shared_object(path))

    def test_empty_dynamic(self) -> None:
        path = self._write(build_elf64(needed=[], soname=None))
        self.assertEqual(parse_needed_libraries(path), set())

    def test_non_elf_returns_empty(self) -> None:
        path = self._write(b"not an elf at all" * 10)
        self.assertEqual(parse_needed_libraries(path), set())

    def test_truncated_file_is_safe(self) -> None:
        full = build_elf64(needed=["libfoo.so"])
        path = self._write(full[:40])  # header only, no program headers
        self.assertEqual(parse_needed_libraries(path), set())

    def test_32bit_support(self) -> None:
        # Build a minimal ELF32 image by hand (LE, e_type=EXEC).
        ident = b"\x7fELF" + bytes([1, 1, 1]) + bytes(9)
        ehdr32 = struct.pack(
            "<16sHHIIIIIHHHHHH",
            ident, 1, 62, 1, 0, 64, 0, 0, 52, 32, 0, 32, 0, 0,
        )
        # 32-bit image with no program headers -> parser must return empty set.
        path = self._write(ehdr32 + bytes(100))
        self.assertEqual(parse_needed_libraries(path), set())
        self.assertTrue(is_elf(path))


if __name__ == "__main__":
    unittest.main()
