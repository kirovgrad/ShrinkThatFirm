"""End-to-end smoke test of the analysis pipeline on a synthetic firmware."""

from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from shrink_that_firm.cli import run
from shrink_that_firm.config import Config
from shrink_that_firm.dup_files import find_duplicate_files
from shrink_that_firm.elf import parse_needed_libraries
from shrink_that_firm.fs import collect_files
from shrink_that_firm.models import UnusedEntry
from shrink_that_firm.report import report_summary, report_unused
from shrink_that_firm.strings import StringIndex
from shrink_that_firm.unused_bins import find_unused_binaries
from shrink_that_firm.unused_libs import collect_needed_references, find_unused_libraries

from .elf_builder import ET_DYN, ET_EXEC, build_elf64

HELLO_TEXT = b"hello firmware world\n"


class PipelineTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.mkdtemp()
        self.root = Path(self._tmp)
        self._make_firmware()

    def tearDown(self) -> None:
        shutil.rmtree(self._tmp, ignore_errors=True)

    def _write(self, rel: str, data: bytes) -> Path:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def _make_firmware(self) -> None:
        # Two identical libraries; one is referenced, one is not.
        libfoo = build_elf64(needed=["libc.so.6"], soname="libfoo.so", e_type=ET_DYN, base=0)
        libbar = build_elf64(needed=["libc.so.6"], soname="libbar.so", e_type=ET_DYN, base=0)

        self._write("lib/libfoo.so", libfoo)
        self._write("lib/libbar.so", libbar)
        (self.root / "lib/libfoo.so.1").symlink_to("libfoo.so")

        # Two executables that reference libfoo; one is itself referenced by an
        # init script (and thus "used"), the duplicate is not.
        app = build_elf64(needed=["libfoo.so"], e_type=ET_EXEC)
        self._write("bin/app", app)
        self._write("bin/app_dup", app)  # byte-identical -> duplicate file
        self._write("bin/app2", build_elf64(needed=["libc.so.6"], e_type=ET_EXEC))

        # Identical config files -> duplicate files.
        self._write("etc/rcS", b"start app\nstart app2\n")
        self._write("etc/cfg.txt", HELLO_TEXT)
        self._write("etc/cfg_copy.txt", HELLO_TEXT)

    def test_duplicate_files(self) -> None:
        files = collect_files(self.root)
        groups = find_duplicate_files(files)
        self.assertEqual(len(groups), 2)
        text_group = next(g for g in groups if g.file_size == len(HELLO_TEXT))
        app_group = next(g for g in groups if g.file_size != len(HELLO_TEXT))
        self.assertEqual(text_group.count, 2)
        self.assertEqual(app_group.count, 2)
        self.assertEqual(app_group.wasted, app_group.file_size)

    def test_needed_references(self) -> None:
        self.assertEqual(
            collect_needed_references(self.root, threads=4),
            {"libfoo.so", "libc.so.6"},
        )

    def test_unused_libraries(self) -> None:
        config = Config(root=self.root, threads=4, output_dir=self.root / "out")
        index = StringIndex.collect(self.root, threads=4)
        unused = find_unused_libraries(config, index)
        self.assertEqual(len(unused), 1)
        entry = unused[0]
        self.assertIsInstance(entry, UnusedEntry)
        self.assertEqual(entry.main_path.name, "libbar.so")

    def test_unused_binaries(self) -> None:
        config = Config(root=self.root, threads=4, output_dir=self.root / "out")
        index = StringIndex.collect(self.root, threads=4)
        unused = find_unused_binaries(config, index)
        names = {e.main_path.name for e in unused}
        self.assertEqual(names, {"app_dup"})

    def test_full_pipeline_writes_reports(self) -> None:
        config = Config(root=self.root, threads=4, output_dir=self.root / "out")
        results = run(config, skip_dup_funcs=True)

        self.assertEqual(len(results.duplicated_files), 2)
        self.assertEqual(len(results.unused_libraries), 1)
        self.assertEqual(len(results.unused_binaries), 1)

        report_summary(config, results, config.root)
        report_unused(config, results.unused_libraries, config.root, "libraries")

        summary = (self.root / "out" / config.report_files["summary"]).read_text()
        self.assertIn("Total wasted space", summary)
        report_text = (self.root / "out" / "unused_library_report.txt").read_text()
        self.assertIn("libbar.so", report_text)

    def test_output_dir_inside_root_is_not_scanned(self) -> None:
        # Reports written inside the firmware tree must not contaminate a
        # subsequent run (their text would "reference" unused binaries).
        out = self.root / "out"
        config = Config(root=self.root, threads=4, output_dir=out)
        for _ in range(2):
            results = run(config, skip_dup_funcs=True)
            self.assertEqual(len(results.unused_libraries), 1)
            self.assertEqual(len(results.unused_binaries), 1)
            report_summary(config, results, config.root)

    def test_elf_files_parse_roundtrip(self) -> None:
        self.assertEqual(parse_needed_libraries(self.root / "bin/app"), {"libfoo.so"})
        self.assertEqual(parse_needed_libraries(self.root / "lib/libfoo.so"), {"libc.so.6"})


if __name__ == "__main__":
    unittest.main()
