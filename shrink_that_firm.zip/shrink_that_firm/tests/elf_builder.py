"""Synthesize minimal valid ELF64 images for testing the pure-Python parser."""

from __future__ import annotations

import struct

ET_EXEC = 2
ET_DYN = 3

_EHDR_FMT = "<16sHHIQQQIHHHHHH"
_PHDR_FMT = "<IIQQQQQQ"
_DYN_FMT = "<qQ"

_PT_LOAD = 1
_PT_DYNAMIC = 2
_DT_NULL = 0
_DT_NEEDED = 1
_DT_STRTAB = 5
_DT_SONAME = 14


def build_elf64(
    needed: list[str] = (),
    soname: str | None = None,
    e_type: int = ET_EXEC,
    base: int = 0x400000,
) -> bytes:
    """Return a small but structurally valid ELF64 image.

    The image has one ``PT_LOAD`` covering the whole file and one
    ``PT_DYNAMIC`` containing ``DT_NEEDED``/``DT_SONAME`` entries plus a
    ``DT_STRTAB`` pointing at an embedded string table.
    """
    names = list(needed)
    if soname and soname not in names:
        names.append(soname)

    dynstr = b"\x00"
    offsets: dict[str, int] = {}
    for name in names:
        offsets[name] = len(dynstr)
        dynstr += name.encode() + b"\x00"
    dynstr += b"\x00" * ((8 - len(dynstr) % 8) % 8)

    dynamic_off = 64 + 2 * 56  # ehdr + two phdrs

    entries: list[tuple[int, int]] = []
    for name in needed:
        entries.append((_DT_NEEDED, offsets[name]))
    if soname:
        entries.append((_DT_SONAME, offsets[soname]))

    dynstr_off = dynamic_off + (len(entries) + 2) * 16
    strtab_vaddr = base + dynstr_off
    entries.append((_DT_STRTAB, strtab_vaddr))
    entries.append((_DT_NULL, 0))

    dynamic_size = len(entries) * 16
    total = dynstr_off + len(dynstr)

    ident = b"\x7fELF" + bytes([2, 1, 1]) + bytes(9)
    ehdr = struct.pack(
        _EHDR_FMT,
        ident,
        e_type,  # e_type
        62,  # e_machine (x86-64)
        1,  # e_version
        0,  # e_entry
        64,  # e_phoff
        0,  # e_shoff
        0,  # e_flags
        64,  # e_ehsize
        56,  # e_phentsize
        2,  # e_phnum
        64,  # e_shentsize
        0,  # e_shnum
        0,  # e_shstrndx
    )

    phdr_load = struct.pack(
        _PHDR_FMT, _PT_LOAD, 5, 0, base, 0, total, total, 0x1000
    )
    phdr_dynamic = struct.pack(
        _PHDR_FMT,
        _PT_DYNAMIC,
        6,
        dynamic_off,
        base + dynamic_off,
        0,
        dynamic_size,
        dynamic_size,
        8,
    )

    dynamic = b"".join(struct.pack(_DYN_FMT, tag, val) for tag, val in entries)

    image = bytearray(total)
    image[:64] = ehdr
    image[64 : 64 + 56] = phdr_load
    image[64 + 56 : 64 + 112] = phdr_dynamic
    image[dynamic_off : dynamic_off + dynamic_size] = dynamic
    image[dynstr_off:] = dynstr
    return bytes(image)
