"""Duplicate file detection.

Groups files by content hash and reports groups that occur more than once.
The old implementation parsed its own CSV output by hand; this one works
directly on the typed ``CollectedFile`` records.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Sequence

from .models import CollectedFile, FileGroup


def find_duplicate_files(files: Sequence[CollectedFile]) -> list[FileGroup]:
    """Return groups of files that share identical content.

    Only groups with at least two members are returned, sorted by wasted bytes
    (descending).
    """
    by_hash: dict[str, list[CollectedFile]] = defaultdict(list)
    for f in files:
        by_hash[f.md5].append(f)

    groups: list[FileGroup] = []
    for digest, members in by_hash.items():
        if len(members) < 2:
            continue
        # Identical hashes imply identical content and size.
        groups.append(
            FileGroup(
                md5=digest,
                file_size=members[0].size,
                paths=tuple(f.path for f in members),
            )
        )

    return sorted(groups, key=lambda g: g.wasted, reverse=True)
