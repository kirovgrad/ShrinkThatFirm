"""IDA script that finds unused functions in the currently open database.

This is a cleaned-up rewrite of the original ``ida_unused_funcs_script.py``.
Run it either:

* automatically, from ``idalib_finder.py`` (which passes ``STRINGS_JSON`` /
  ``RESULT_JSON`` in the execution globals), or
* manually inside IDA Pro: File > Script file... (configure paths through the
  ``STF_*`` environment variables, see below).

The algorithm is unchanged: it walks the call graph from ``main``, exports,
``.init_array``/``.fini_array`` and global function-pointer arrays, then reports
every remaining function in ``.text`` as potentially unused.

Configuration (environment variables, used only when the globals are absent):

* ``STF_STRINGS_JSON``  - path to the strings collected from all other files
                          (default ``collected_strings.json``)
* ``STF_RESULT_JSON``   - where to append ``{binary: [unused funcs]}``
                          (default ``result.json``)
* ``STF_MIN_FUNC_SIZE`` - functions smaller than this are considered inlined
                          and are kept (default ``140``)
* ``STF_INCLUDE_SMALL`` - set to ``1`` to *disable* the small-function filter
"""

from __future__ import annotations

import json
import os
import re
import struct

_STRINGS_JSON = globals().get("STRINGS_JSON") or os.environ.get(
    "STF_STRINGS_JSON", "collected_strings.json"
)
_RESULT_JSON = globals().get("RESULT_JSON") or os.environ.get(
    "STF_RESULT_JSON", "result.json"
)
_MIN_FUNC_SIZE = int(globals().get("MIN_FUNC_SIZE") or os.environ.get("STF_MIN_FUNC_SIZE", "140"))
_INCLUDE_SMALL = os.environ.get("STF_INCLUDE_SMALL") == "1"

try:  # IDA-specific imports only exist inside an IDA process.
    import ida_entry  # noqa: PLC0415
    import ida_funcs  # noqa: PLC0415
    import ida_nalt  # noqa: PLC0415
    import ida_name  # noqa: PLC0415
    import ida_search  # noqa: PLC0415
    import ida_segment  # noqa: PLC0415
    import ida_xref  # noqa: PLC0415
    import idaapi  # noqa: PLC0415
    import idautils  # noqa: PLC0415
    import idc  # noqa: PLC0415
except ImportError:
    ida_entry = ida_funcs = ida_nalt = ida_name = ida_search = None
    ida_segment = ida_xref = idaapi = idautils = idc = None

_DATA_PREFIXES = ("g_", "off_", "unk_", "dword_")


def _seg_name(seg) -> str:
    return ida_segment.get_segm_name(seg) if seg is not None else ""


def parse_data_segment(segm_name: str) -> dict[int, list[int]]:
    """Find pointer-sized arrays in a data segment that contain code addresses.

    Returns ``{array_ea: [pointed values]}`` for every named array whose 4-byte
    elements point at a function or at another named data object.
    """
    seg = idaapi.get_segm_by_name(segm_name)
    if not seg:
        return {}

    named_eas = sorted(
        ea
        for ea in idautils.Heads(seg.start_ea, seg.end_ea)
        if idc.get_name(ea, ida_name.GN_VISIBLE).startswith(_DATA_PREFIXES)
    )

    arrays: dict[int, list[int]] = {}
    end = seg.end_ea

    for i, ea in enumerate(named_eas):
        name = idc.get_name(ea, ida_name.GN_VISIBLE)
        next_addr = named_eas[i + 1] if i + 1 < len(named_eas) else end
        size = next_addr - ea
        if size <= 0:
            continue

        data = idaapi.get_bytes(ea, size)
        if not data:
            continue

        values: list[int] = []
        for j in range(0, len(data) - len(data) % 4, 4):
            value = struct.unpack("<I", data[j : j + 4])[0]
            if idc.get_func_name(value) or idc.get_name(value, ida_name.GN_VISIBLE).startswith(
                _DATA_PREFIXES
            ):
                values.append(value)
        if values:
            arrays[ea] = values

    return arrays


def find_array_references(array_ea: int) -> list[str]:
    """Names of functions that reference ``array_ea`` via data xrefs."""
    funcs: list[str] = []
    for ref in idautils.DataRefsTo(array_ea):
        func_name = idc.get_func_name(ref)
        if func_name and func_name not in funcs:
            funcs.append(func_name)
    return funcs


def check_segment(ea: int, seg_name: str) -> bool:
    seg = ida_segment.getseg(ea)
    return _seg_name(seg) == seg_name


def get_called_functions(func_ea: int) -> set[int]:
    """Addresses of functions directly called (or jumped into) by ``func_ea``."""
    called: set[int] = set()
    func = ida_funcs.get_func(func_ea)
    if not func:
        return called

    ea = func.start_ea
    while ea < func.end_ea:
        for xref in idautils.XrefsFrom(ea, ida_xref.XREF_FAR):
            target = ida_funcs.get_func(xref.to)
            if target is None:
                continue
            if xref.type in (ida_xref.fl_CN, ida_xref.fl_CF, ida_xref.dr_O):
                called.add(target.start_ea)
            elif xref.type in (ida_xref.fl_JN, ida_xref.fl_JF) and target.start_ea == xref.to:
                called.add(target.start_ea)
        ea = idc.next_head(ea, func.end_ea)

    return called


def get_exported_funcs() -> list[int]:
    return [ida_entry.get_entry(ida_entry.get_entry_ordinal(i)) for i in range(ida_entry.get_entry_qty())]


def find_unneeded_and_delete(exported_funcs: list[int]) -> None:
    """Filter exports: drop names that cannot be reached by other files."""
    try:
        with open(_STRINGS_JSON) as fh:
            collected_strings = json.load(fh)
    except OSError:
        return

    root_filename = ida_nalt.get_root_filename()
    other_strings: set[str] = set()
    asp_strings: list[str] = []

    for file, strings in collected_strings.items():
        if os.path.basename(file) == root_filename:
            continue
        if file.endswith(".asp"):
            asp_strings.extend(s for s in strings if "%" in s and "<" in s)
        else:
            other_strings.update(strings)

    kept: list[int] = []
    for func_ea in exported_funcs:
        func_name = idc.get_func_name(func_ea)
        if not func_name:
            continue
        if not (func_name[0].isalpha() and (func_name[0].isupper() or "_" in func_name[1:])):
            continue
        if func_name in other_strings:
            kept.append(func_ea)
            continue
        pattern = re.compile(rf"<%{re.escape(func_name)}.*%>")
        if any(pattern.search(s) for s in asp_strings):
            kept.append(func_ea)

    exported_funcs[:] = kept


def is_function_pointer(addr: int) -> bool:
    return idaapi.get_func(addr) is not None


def _expand_array(array: list[int], arrays: dict[int, list[int]], visited: set[int]) -> set[int]:
    """Resolve nested arrays of pointers into the set of function addresses."""
    functions: set[int] = set()
    for value in array:
        if is_function_pointer(value):
            functions.add(value)
        elif value in arrays and value not in visited:
            visited.add(value)
            functions |= _expand_array(arrays[value], arrays, visited)
    return functions


def array_resolver(array_result: dict[int, list[int]]) -> dict[int, list[int]]:
    return {
        key: sorted(_expand_array(values, array_result, set()))
        for key, values in array_result.items()
    }


def find_arrays_with_func() -> list[tuple[list[str], list[int]]]:
    arrays = {}
    for seg_name in (".data", ".data.rel.ro"):
        arrays.update(parse_data_segment(seg_name))
    arrays = array_resolver(arrays)

    funcs_refs: list[tuple[list[str], list[int]]] = []
    for var_addr, references in arrays.items():
        refs = find_array_references(var_addr)
        if refs:
            funcs_refs.append((refs, references))
    return funcs_refs


def find_main_function(current_filename: str, need_to_process: list[int]) -> None:
    if ".ko" in current_filename or ".so" in current_filename:
        return
    main_func = ida_name.get_name_ea(0, "main")
    if main_func != idc.BADADDR:
        need_to_process.append(main_func)
        return
    libc_start = ida_name.get_name_ea(0, "__libc_start_main")
    for ref in idautils.CodeRefsTo(libc_start, True):
        func = ida_funcs.get_func(ref)
        if func:
            need_to_process.append(func.start_ea)


def process_funcs(need_to_process: list[int], funcs_refs: list[tuple[list[str], list[int]]]) -> set[int]:
    """Breadth-first walk from entry points; returns every reachable function."""
    processed: set[int] = set()
    queue = list(need_to_process)

    while queue:
        current = queue.pop(0)
        if current in processed:
            continue
        processed.add(current)

        current_func_name = idc.get_name(current)
        for callee in get_called_functions(current):
            if callee not in processed:
                queue.append(callee)

        for ref_funcs, array_funcs in funcs_refs:
            if current_func_name in ref_funcs:
                for ea in array_funcs:
                    if ea not in processed:
                        queue.append(ea)

    return processed


def find_init_fini_functions() -> list[int]:
    result = []
    for func in idautils.Functions():
        for ref in idautils.DataRefsTo(func):
            if _seg_name(ida_segment.getseg(ref)) in (".init_array", ".fini_array"):
                result.append(func)
    return result


def resolve_not_funcs() -> None:
    """Define functions over code that IDA left undefined."""
    ea = ida_search.find_not_func(1, 1)  # SEARCH_DOWN
    while ea != idc.BADADDR:
        ida_funcs.add_func(ea)
        ea = ida_search.find_not_func(ea, 1)


def filter_small_funcs() -> list[int]:
    """Functions too small to be genuinely dead; assume they were inlined."""
    small: list[int] = []
    for func in idautils.Functions():
        if not check_segment(func, ".text"):
            continue
        f = ida_funcs.get_func(func)
        if f and (f.end_ea - f.start_ea) < _MIN_FUNC_SIZE:
            small.append(func)
    return small


def main() -> None:
    resolve_not_funcs()

    current_filename = ida_nalt.get_root_filename()
    funcs_refs = find_arrays_with_func()

    need_to_process: list[int] = []
    find_main_function(current_filename, need_to_process)

    exported_funcs = get_exported_funcs()
    if exported_funcs:
        find_unneeded_and_delete(exported_funcs)
    need_to_process.extend(exported_funcs)

    need_to_process.extend(find_init_fini_functions())
    if _INCLUDE_SMALL:
        need_to_process.extend(filter_small_funcs())

    processed = process_funcs(need_to_process, funcs_refs)

    unneeded: list[tuple[str, int, int]] = []
    combined_size = 0
    for func in idautils.Functions():
        if func in processed:
            continue
        name = idc.get_name(func)
        if not name or not name[0].isalpha() or not check_segment(func, ".text"):
            continue
        f = ida_funcs.get_func(func)
        if not f:
            continue
        size = f.end_ea - f.start_ea
        combined_size += size
        unneeded.append((name, func, size))

    try:
        with open(_RESULT_JSON) as fh:
            result = json.load(fh)
    except (OSError, json.JSONDecodeError):
        result = {}
    result[current_filename] = unneeded
    with open(_RESULT_JSON, "w") as fh:
        json.dump(result, fh)


if idc is not None:
    main()
