"""Headless IDA driver: find unused functions in every ELF binary.

This is a cleaned-up rewrite of the original ``unused_funcs_finder.py``.

Key changes:

* proper CLI (argparse) instead of bare ``sys.argv[1]``,
* pathlib + str instead of ``file.split("\\\\")[-1]`` (a Windows-only habit
  that breaks on POSIX paths),
* ``ida`` / ``ida_idaapi`` are imported lazily so the module can be imported
  without IDA installed,
* string collection is delegated to the shared ``strings`` machinery,
* configurable worker count and error log path,
* the IDA script is located relative to this module, not the CWD.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import sys
from pathlib import Path

from ..elf import is_elf
from ..progress import ProgressBar, get_logger, setup_logging
from ..strings import StringIndex

logger = get_logger()

_SCRIPT = Path(__file__).parent / "idb_script.py"


def collect_executables(root: Path, max_workers: int) -> list[Path]:
    """Return every non-symlink ELF file under ``root`` (sorted)."""
    files = [
        path
        for dirpath, _, names in os.walk(root)
        for path in (Path(dirpath) / n for n in names)
        if path.is_file() and not path.is_symlink() and is_elf(path)
    ]
    return sorted(files)


def _run_ida(path: Path, collected_strings_file: Path, result_file: Path, error_log: Path) -> None:
    """Open one database in headless IDA, run the analysis script, close it."""
    import ida  # noqa: PLC0415 - only importable inside an idalib process
    import ida_idaapi  # noqa: PLC0415

    logger.info("Opening %s with IDA...", path)
    try:
        ida.open_database(str(path), True)
        try:
            globals_dict = {
                "STRINGS_JSON": str(collected_strings_file),
                "RESULT_JSON": str(result_file),
            }
            ida_idaapi.IDAPython_ExecScript(str(_SCRIPT), globals_dict)
        finally:
            ida.close_database(save=False)
    except Exception as exc:  # noqa: BLE001 - keep analysing the rest
        with error_log.open("a") as fh:
            fh.write(f"Error processing file: {path} {exc}\n")
        logger.warning("Failed to analyze %s: %s", path, exc)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="shrink_that_firm.ida",
        description="Use IDA Pro 9+ (idalib) to find unused functions in ELF binaries.",
    )
    parser.add_argument("root", help="Path to the extracted firmware filesystem.")
    parser.add_argument("-t", "--threads", type=int, default=1,
                        help="Number of concurrent IDA workers (default: 1).")
    parser.add_argument("--ignore", nargs="*", default=["libc.so"],
                        help="Library basenames to skip (default: libc.so).")
    parser.add_argument("--collected-strings", type=Path, default=Path("collected_strings.json"))
    parser.add_argument("--result", type=Path, default=Path("result.json"))
    parser.add_argument("--error-log", type=Path, default=Path("output_errors.txt"))
    parser.add_argument("-v", "--verbose", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    setup_logging(verbose=args.verbose)

    root = Path(args.root)
    if not root.is_dir():
        logger.error("%s is not a directory", root)
        return 1

    logger.info("Collecting ELF executables from %s...", root)
    executables = collect_executables(root, args.threads)
    ignore = set(args.ignore)
    executables = [e for e in executables if e.name not in ignore]

    logger.info("Collecting strings...")
    index = StringIndex.collect(root, threads=max(args.threads, 8))
    with args.collected_strings.open("w") as fh:
        json.dump({str(p): s for p, s in index.entries.items()}, fh)

    with args.result.open("w") as fh:
        json.dump({}, fh)

    bar = ProgressBar(len(executables))
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as pool:
        futures = [
            pool.submit(_run_ida, e, args.collected_strings, args.result, args.error_log)
            for e in executables
        ]
        for done in concurrent.futures.as_completed(futures):
            done.result()
            bar.update()

    logger.info("Finished. Results in %s", args.result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
