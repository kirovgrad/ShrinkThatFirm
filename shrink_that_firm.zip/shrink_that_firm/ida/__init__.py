"""IDA-based analysis: finding unused functions with IDA Pro 9+ (idalib)."""
